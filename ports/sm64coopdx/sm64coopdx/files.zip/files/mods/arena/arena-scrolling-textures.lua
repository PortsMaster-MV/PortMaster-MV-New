--Scrolling Textures for Rainbow Road
add_scroll_target(0, "arena_rainbow_dl_StarRoad_mesh_layer_5_vtx_0", 0, 539)
add_scroll_target(1, "arena_rainbow_dl_RoadBuilding_mesh_layer_1_vtx_0", 0, 122)
add_scroll_target(2, "arena_rainbow_dl_StarRoad_mesh_layer_5_vtx_3", 0, 587)
add_scroll_target(3, "arena_rainbow_dl_StarRoad_mesh_layer_5_vtx_2", 0, 249)
add_scroll_target(4, "arena_rainbow_dl_StarRoad_mesh_layer_5_vtx_1", 0, 1096)
add_scroll_target(5, "arena_rainbow_dl_Main_Platform_mesh_layer_5_vtx_0", 0, 1060)
add_scroll_target(6, "arena_rainbow_dl_Torus_mesh_layer_5_vtx_0", 0, 880)
--Stars
add_scroll_target(7, "arena_rainbow_dl_FlagPositionsStars1_mesh_layer_5_vtx_0", 0, 68)
add_scroll_target(8, "arena_rainbow_dl_FlagPositionsStars1_mesh_layer_5_vtx_1", 0, 68)
add_scroll_target(9, "arena_rainbow_dl_FlagPositionsStars2_mesh_layer_5_vtx_0", 0, 68)
add_scroll_target(10, "arena_rainbow_dl_FlagPositionsStars2_mesh_layer_5_vtx_1", 0, 68)
--MidStarRoad
add_scroll_target(11, "arena_rainbow_dl_StarRoadMidAmbience_mesh_layer_5_vtx_1", 0, 290)
--GreyStars
add_scroll_target(12, "arena_rainbow_dl_FlagPositionsGraySideStars_mesh_layer_5_vtx_0", 0, 272)
add_scroll_target(13, "arena_rainbow_dl_FlagPositionsGrayTopStars_mesh_layer_5_vtx_0", 0, 136)

--Scrolling Textures for Blimp City
add_scroll_target(14, "arena_city_dl_RedRoad_mesh_layer_5_vtx_0", 0, 4)
add_scroll_target(15, "arena_city_dl_BlueRoad_mesh_layer_5_vtx_0", 0, 4)
add_scroll_target(16, "arena_city_dl_Signs_mesh_layer_5_vtx_0", 0, 12)
add_scroll_target(17, "arena_city_dl_Signs_mesh_layer_5_vtx_1", 0, 12)
add_scroll_target(18, "arena_city_dl_Beam_mesh_layer_1_vtx_0", 0, 78)