smlua_text_utils_dialog_replace(DIALOG_000, 1, 6, 30, 200, "--WARNING--\
FLOOR UNSTABLE. DO NOT\
GROUND-POUND UNDER \
ANY CIRCUMSTANCES!'")

smlua_text_utils_dialog_replace(DIALOG_001, 1, 4, 95, 200, "Hey, you! You better be \
pretty careful unless you\
want to be blasted by a\
water bomb from our \
enemy! We are peaceful\
Bob-ombs who love the\
ocean and sky, but these\
other guys are completely\
war-hungry! Their leader\
is Big Bob-omb, he stole\
a ★ from us and is using\
it to win this battle.\
Say, you look pretty \
tough. Do you think you \
could do us a favor and \
get our ★ back?\
Good luck!")

smlua_text_utils_dialog_replace(DIALOG_002, 1, 3, 95, 200, "It's a good thing we\
sunk their ship early\
in the battle, I hate\
to think what damage\
those cannons could\
have done!")

smlua_text_utils_dialog_replace(DIALOG_003, 1, 5, 95, 200, "Hey Mario, good to see\
you once more!\
I came here to catch the\
train to Koopa City,\
but the whole station \
is in a chaotic mess!\
It looks like I'll have\
to go explore somewhere\
else, but hey, if you are\
staying here... here's a\
little hint:\
I heard that the Wing Cap\
Switch is hidden around\
here. I suspect that those\
strange flying thwomps\
have something to do\
with it, but you can \
find out for yourself.\
\
See ya!")

smlua_text_utils_dialog_replace(DIALOG_004, 1, 4, 95, 200, "You need to\
use our cannon? Sure!\
Just wait a moment while\
I open it up for you...")

smlua_text_utils_dialog_replace(DIALOG_005, 1, 3, 30, 200, "Hey, Mario! I've been\
practicing running to\
the top of Koopa Canyon.\
Do you think you have\
what it takes to beat me\
this time? I'm really,\
REALLY fast now! \
First one to\
the rock pillars wins.\
\
Ready....\
\
//Go!////Don't Go")

smlua_text_utils_dialog_replace(DIALOG_006, 1, 3, 30, 200, "Hey!!! Don't try to scam\
ME. You've gotta run\
the whole course.\
Later. Look me up when\
you want to race for\
real.")

smlua_text_utils_dialog_replace(DIALOG_007, 1, 3, 30, 200, "Wow, I can't believe you\
still beat me after all \
that training! Maybe I\
shouldn't have shown off\
by running around those\
pillars...\
Anyway, here's \
your prize.")

smlua_text_utils_dialog_replace(DIALOG_008, 1, 4, 30, 200, "It's locked... But wait,\
there is supposed to be\
another entrance \
hidden in Gloomy Garden.\
Have you found it yet?\
Make sure you search\
every dark corner in the\
whole garden...")

smlua_text_utils_dialog_replace(DIALOG_009, 1, 5, 30, 200, "Nice to see you again,\
Mario. It sure has been\
a while. How about a \
race? First to the \
top of the mountain!\
\
//Go//// Don't Go")

smlua_text_utils_dialog_replace(DIALOG_010, 1, 4, 30, 200, "You've stepped on the\
Wing Cap Switch. Wearing\
the Wing Cap, you can\
soar through the sky.\
Now Wing Caps will pop\
out of all the red blocks\
you find.\
\
Would you like to Save?\
\
//Yes////No")

smlua_text_utils_dialog_replace(DIALOG_011, 1, 4, 30, 200, "You've just stepped on\
the Metal Cap Switch!\
The Metal Cap makes\
Mario invincible.\
Now Metal Caps will\
pop out of all of the\
green blocks you find.\
\
Would you like to Save?\
\
//Yes////No")

smlua_text_utils_dialog_replace(DIALOG_012, 1, 4, 30, 200, "You've just stepped on\
the Vanish Cap Switch.\
The Vanish Cap makes\
Mario disappear.\
Now Vanish Caps will pop\
from all of the blue\
blocks you find.\
\
Would you like to Save?\
\
//Yes////No")

smlua_text_utils_dialog_replace(DIALOG_013, 1, 5, 30, 200, "You've collected 100\
coins! Mario gains more\
power from the stars.\
Do you want to Save?\
//Yes////No")

smlua_text_utils_dialog_replace(DIALOG_014, 1, 4, 30, 200, "Wow! Another Power Star!\
Mario gains more courage\
from the power of the\
stars.\
Do you want to Save?\
\
//You Bet//Not Now")

smlua_text_utils_dialog_replace(DIALOG_015, 1, 4, 30, 200, "Hey there, don't\
mistake me for those\
other hot-heads, I'm not\
the sort to blow my top.\
I'm Bob, and you are...?\
Nice to meet you, Mario!\
I came here to watch\
the Chuckya Chucking\
Competition, but it's\
been postponed, so I'll\
have to simmer around \
'till next week. \
Since you're exploring\
this place, I'll give\
you a hint. I heard that\
the Chuckyas have hidden\
the Metal Cap Switch\
somewhere around here. \
They probably used a\
purple switch to hide\
the entrance.\
Good luck finding it!")

smlua_text_utils_dialog_replace(DIALOG_016, 1, 3, 30, 200, "See the 1-up symbols on\
these pillars? Stand on\
all four and you will\
win a prize! Well, if you\
can catch it...")

smlua_text_utils_dialog_replace(DIALOG_017, 1, 4, 30, 200, "You again! Are you\
following me or what?\
Well, you better prepare \
yourself for a tough \
battle if you think \
you're going to go taking \
my power star again!\
Because I'm not going to\
go easy on you this time!")

smlua_text_utils_dialog_replace(DIALOG_018, 1, 2, 30, 200, "The life... \
It's fading.")

smlua_text_utils_dialog_replace(DIALOG_019, 1, 4, 30, 200, "Hmm, Lakitu is probably\
going to have trouble\
fitting through this\
small entrance. If you\
are using the SM64SR\
Camera Control code,\
hold [R] as you enter\
the cave to help him in.")

smlua_text_utils_dialog_replace(DIALOG_020, 1, 6, 95, 150, "Dear Mario,\
I just wanted to wish\
you luck and tell you \
that I'm sure we'll see \
each other again soon!")

smlua_text_utils_dialog_replace(DIALOG_021, 1, 5, 95, 200, "BOWSER SOUND EFFECT")

smlua_text_utils_dialog_replace(DIALOG_022, 1, 2, 95, 200, "You cannot open this\
door yet.")

smlua_text_utils_dialog_replace(DIALOG_023, 1, 3, 95, 200, "This key doesn't fit!")

smlua_text_utils_dialog_replace(DIALOG_024, 1, 5, 95, 200, "You do not have enough\
power stars to break the\
seal on this door.")

smlua_text_utils_dialog_replace(DIALOG_025, 1, 4, 95, 200, "You do not have enough\
power stars to break the\
seal on this door.")

smlua_text_utils_dialog_replace(DIALOG_026, 1, 4, 95, 200, "You do not have enough\
power stars to break the\
seal on this door.")

smlua_text_utils_dialog_replace(DIALOG_027, 1, 4, 95, 200, "You do not have enough\
power stars to break the\
seal on this door.")

smlua_text_utils_dialog_replace(DIALOG_028, 1, 4, 95, 200, "You do not have enough\
power stars to break the\
seal on this door.")

smlua_text_utils_dialog_replace(DIALOG_029, 1, 5, 95, 200, "You do not have enough\
power stars to break the\
seal on this door.")

smlua_text_utils_dialog_replace(DIALOG_030, 1, 6, 30, 200, "Did you know that it is\
possible for a plumber\
with exceptional jumping\
skills to jump up a steep \
hill? You can do this\
by landing on the slope\
after your second hop\
then pressing [A] once \
more to triple-jump.")

smlua_text_utils_dialog_replace(DIALOG_031, 1, 5, 30, 200, "Woah, you completely\
stomped my record! I\
promise I'll train\
extra hard for our\
next race. Until\
next time, here is\
your prize.\
Congrats, Mario!")

smlua_text_utils_dialog_replace(DIALOG_032, 1, 2, 30, 200, "Mario...\
You can't let Bowser win!")

smlua_text_utils_dialog_replace(DIALOG_033, 1, 6, 30, 200, "Well done, Mario!\
You've always been\
there to help out when\
we need you. You have\
everyone's thanks for\
collecting every ★ \
so we can finally \
use them to drive out \
the last of Bowser's\
evil minions.")

smlua_text_utils_dialog_replace(DIALOG_034, 1, 6, 30, 200, "Good afternoon. The\
Lakitu Bros., here,\
reporting live from just\
outside the Princess's\
castle.\
\
Mario has just arrived\
on the scene, and we'll\
be filming the action live\
as he enters the castle\
and pursues the missing\
Power Stars.\
As seasoned cameramen,\
we'll be shooting from the\
recommended angle, but\
you can change the\
camera angle by pressing\
the [C] Buttons.\
If we can't adjust the\
view any further, we'll\
buzz. To take a look at\
the surroundings, stop\
and press [C]^.\
\
Press [A] to resume play.\
Switch camera modes with\
the [R] Button. Signs along\
the way will review these\
instructions.\
\
For now, reporting live,\
this has been the\
Lakitu Bros.")

smlua_text_utils_dialog_replace(DIALOG_035, 1, 5, 30, 200, "Wow Mario, you really\
have all the power\
stars? I hope you\
enjoyed your journey, I\
know how you love the\
thrill of ducking and\
dodging obstacles all\
day. That's why I took\
the time to hide 9 of\
my star replicas across\
the lands. If you are\
ready for your next\
little journey, have\
a go at collecting them\
all. Be warned though,\
I didn't make them simple\
to find! You can easily \
recognize a star replica \
because it doesn't spin, \
since it has no real \
power. Take a look at\
the sign post next to\
me, I listed all the\
levels where I hid\
star replicas.")

smlua_text_utils_dialog_replace(DIALOG_036, 1, 5, 30, 200, "You're the greatest,\
Mario! I was so sick of\
those goombas breaking\
into my house to jump\
on my bed!")

smlua_text_utils_dialog_replace(DIALOG_037, 1, 2, 30, 200, "I win! Better luck next\
time, pal.")

smlua_text_utils_dialog_replace(DIALOG_038, 1, 3, 95, 200, "The power of your stars\
has broken the seal on\
this door!")

smlua_text_utils_dialog_replace(DIALOG_039, 1, 4, 30, 200, "Did you ever work out\
how to reach the lookout\
on top of Star-Leap\
Tower? All I know is\
that the pipe leading\
there is hidden\
somewhere very windy.")

smlua_text_utils_dialog_replace(DIALOG_040, 1, 3, 30, 200, "Are you going go keep\
searching for the power\
stars now, Mario? When\
you're ready, go and\
grab Bowser's power\
star over there.")

smlua_text_utils_dialog_replace(DIALOG_041, 1, 3, 30, 200, "I win! You lose!\
Ha ha ha!\
\
Not looking so speedy\
now, are you Mario?")

smlua_text_utils_dialog_replace(DIALOG_042, 1, 4, 30, 200, "This is a great spot\
to sit and stare at the\
stars...")

smlua_text_utils_dialog_replace(DIALOG_043, 1, 5, 30, 200, "Hey you, get off my\
roof! You're too heavy,\
you'll break it!")

smlua_text_utils_dialog_replace(DIALOG_044, 1, 5, 95, 200, "Whooo's there? Whooo\
disturbed my dinner?\
Oh, it's you, Mario!\
I haven't seen you in\
a long time! I moved\
to this pond after I\
got sick of all the\
groaning those thwomps\
and whomps were making.\
\
So, do you need a ride?")

smlua_text_utils_dialog_replace(DIALOG_045, 1, 6, 95, 200, "Whew! I really don't\
think I can hold you\
much longer. I still\
think you should cut\
down on the spaghetti.")

smlua_text_utils_dialog_replace(DIALOG_046, 1, 4, 30, 200, "Oh dear, Mario forgot\
how to climb ladders\
again! It looks like he\
will have to go around.")

smlua_text_utils_dialog_replace(DIALOG_047, 1, 2, 95, 200, "Hi! I'll prepare the\
cannon for you!")

smlua_text_utils_dialog_replace(DIALOG_048, 1, 3, 30, 200, "It's not over yet.\
Jump into the vortex\
and this never happened.")

smlua_text_utils_dialog_replace(DIALOG_049, 1, 5, 30, 200, "Great job unlocking\
the door, Mario!\
Have a look around and\
I'm sure you will find\
some more stars. \
Oh, by the way, don't be\
freaked out by the size\
of this place. The\
star spirits enchanted\
Star-Leap Tower so it\
could be larger on the\
inside. It's pretty\
amazing what they can\
do!")

smlua_text_utils_dialog_replace(DIALOG_050, 1, 4, 30, 200, "Brrr, this place gives\
me the creeps, Mario!\
I don't really fancy\
hanging around with\
these ghosts much\
longer. It's a shame\
the Vanish Cap Switch\
is in this place,\
there's no telling where\
those mischievous ghosts\
could of have hid it!")

smlua_text_utils_dialog_replace(DIALOG_051, 1, 5, 30, 200, "I wanted to play the\
piano, but I couldn't\
reach! Really, was that\
piano made for giants\
or what?\
Oh well, I guess there\
are more important\
problems at the moment.\
Say, have you tried\
climbing onto the\
chandelier in the\
entrance room? If you\
can long-jump onto it,\
maybe you'll find\
something!")

smlua_text_utils_dialog_replace(DIALOG_052, 1, 2, 30, 200, "CREEPY CAP CAVE \
\
PUZZLE OF THE\
VANISH CAP\
WINDY WING CAP WELL\
\
BOWSER'S \
SLIPPERY SWAMP\
RETRO REMIX CASTLE\
\
BOWSER'S \
RAINBOW RUMBLE\
MUSHROOM \
MOUNTAIN TOWN\
SANDY SLIDE SECRET\
\
HIDDEN PALACE FINALE")

smlua_text_utils_dialog_replace(DIALOG_053, 1, 3, 30, 200, "If you look up, you can\
see the satellite used \
by this base.")

smlua_text_utils_dialog_replace(DIALOG_054, 1, 5, 30, 200, "Wow, you found the\
Sandy Slide Secret!\
\
There are two stars here,\
one for finishing the\
slide in 18 seconds, and\
another for collecting\
all the red coins.\
Be careful though, if\
you fail to collect\
one of these then you \
will have no choice but\
to lose a life! \
\
There are plenty of lives \
hidden in this level... \
can you find them all?\
")

smlua_text_utils_dialog_replace(DIALOG_055, 1, 4, 30, 200, "Hey Mario, remember me?\
I'm Tuxie! Thanks for\
helping me out when I\
was lost a few years ago.\
Since then, I've been\
practicing racing so I \
can be as fast as my Dad.\
So, how about a race?\
Ready...\
\
//Go//// Don't Go")

smlua_text_utils_dialog_replace(DIALOG_056, 1, 6, 30, 200, "Wow, you're so fast! \
Here, take this.\
I don't have a medal,\
but this shiny ★ looks\
kinda like one.")

smlua_text_utils_dialog_replace(DIALOG_057, 1, 4, 30, 200, "Ugh! How many times do\
I have to tell my silly\
child not to wander off?\
While he's wandering\
around these dangerous\
cliffs, I have to sit \
here worrying myself \
sick!")

smlua_text_utils_dialog_replace(DIALOG_058, 1, 4, 30, 200, "Thank you so much for\
finding my naughty\
child! I'll have to\
keep a closer eye on\
him from now on.\
If you like, you\
can take this ★ I found\
as my thanks.")

smlua_text_utils_dialog_replace(DIALOG_059, 1, 4, 30, 200, "I'm going to keep\
practicing so I can beat\
you one day!")

smlua_text_utils_dialog_replace(DIALOG_060, 1, 5, 30, 200, "If you can shoot through\
all five of those hoops,\
I bet a ★ will appear. \
Just press the purple \
switch and hop in either \
side of the turret, then \
I'll climb through this \
hatch and aim for you.")

smlua_text_utils_dialog_replace(DIALOG_061, 1, 4, 30, 200, "Do you think Lakitu is \
doing a bad job today? \
Try the code on the next \
sign. Controlling this new \
camera is simple! The \
camera will stay in the \
default zoomed-out \
position unless you are \
holding down [R], which will \
make it zoom in. \
Much better!")


smlua_text_utils_dialog_replace(DIALOG_063, 1, 5, 30, 200, "I AM ERROR.")

smlua_text_utils_dialog_replace(DIALOG_064, 1, 5, 30, 200, "To Flowpipe Sewer.")

smlua_text_utils_dialog_replace(DIALOG_065, 1, 6, 30, 200, "It's time for the final\
showdown with Bowser!\
Good luck, and \
thank you for playing.\
It's not all over after\
this, though... You\
haven't got all 120 stars\
yet, right? See if you\
can gather them all up,\
and maybe something\
good will happen...")

smlua_text_utils_dialog_replace(DIALOG_066, 1, 5, 30, 200, "Have you seen that huge \
broken star in the sky? \
It certainly wasn't like \
that when I last saw it \
a few years ago. I've \
heard rumors that the \
star spirits recently had \
a war up there with \
something so immensely \
powerful that the whole \
place shattered! It \
sounds so cool, I wish I \
could have seen it! But \
then again, if I were \
close enough to see it, \
I'd probably be \
done for...")

smlua_text_utils_dialog_replace(DIALOG_067, 1, 5, 30, 200, "Too bad I couldn't stop\
by to talk to you in\
person, Mario, but I'm\
a little busy taking\
over the Mushroom\
Kingdom to deal with\
pests like you. Instead,\
why don't you meet the\
Pernicious Piranha Plants? \
Just be warned, they \
have quite an appetite \
for pesky plumbers!\
Bwa ha ha!")

smlua_text_utils_dialog_replace(DIALOG_068, 1, 5, 30, 200, "It's Lethal Lava Land!\
If you catch fire or fall\
into a pool of flames,\
you'll be hopping mad, but\
don't lose your cool.\
You can still control\
Mario--just try to keep\
calm!")

smlua_text_utils_dialog_replace(DIALOG_069, 1, 6, 30, 200, "Sometimes you'll bump into\
invisible walls at the\
edges of the painting\
worlds. If you hit a wall\
while flying, you'll bounce\
back.")

smlua_text_utils_dialog_replace(DIALOG_070, 1, 5, 30, 200, "You can return to the\
castle's main hall at any\
time from the painting\
worlds where the enemies\
live.\
Just stop, stand still,\
press Start to pause the\
game, then select\
『Exit Course.』\
\
You don't have to collect\
all Power Stars in one\
course before going on to\
the next.\
\
Return later, when you're\
more experienced, to pick\
up difficult ones.\
\
\
Whenever you find a Star,\
a hint for finding the\
next one will appear on\
the course's start screen.\
\
You can, however, collect\
any of the remaining\
Stars next. You don't\
have to recover the one\
described by the hint.")

smlua_text_utils_dialog_replace(DIALOG_071, 1, 3, 30, 200, "Danger Ahead!\
Beware of the strange\
cloud! Don't inhale!\
If you feel faint, run for\
higher ground and fresh\
air!\
Circle: Shelter\
Arrow: Entrance-Exit")

smlua_text_utils_dialog_replace(DIALOG_072, 1, 4, 30, 200, "NOTICE:\
This Star Road cannot\
function without at\
least 65 power stars.\
If the Star Road stops\
working at any point,\
this should be the\
first thing you check.")

smlua_text_utils_dialog_replace(DIALOG_073, 1, 2, 95, 200, "Trying to take shortcuts\
can backfire...")

smlua_text_utils_dialog_replace(DIALOG_074, 1, 5, 30, 200, "You can grab on to the\
edge of a cliff or ledge\
with your fingertips and\
hang down from it.\
\
To drop from the edge,\
either press the Control\
Stick in the direction of\
Mario's back or press the\
[Z] Button.\
To get up onto the ledge,\
either press Up on the\
Control Stick or press [A]\
as soon as you grab the\
ledge to climb up quickly.")

smlua_text_utils_dialog_replace(DIALOG_075, 1, 5, 30, 200, "Mario!! My castle is in\
great peril. I know that\
Bowser is the cause...and\
I know that only you can\
stop him!\
The doors in the castle\
that have been sealed by\
Bowser can be opened only\
with Star Power.\
\
But there are secret\
paths in the castle,\
paths that Bowser hasn't\
found.\
\
One of those paths is in\
this room, and it holds\
one of the castle's Secret\
Stars!\
\
Find that Secret Star,\
Mario! It will help you\
on your quest. Please,\
Mario, you have to\
help us!\
Retrieve all of the\
Power Stars in the castle\
and free us from this\
awful prison!\
Please!")

smlua_text_utils_dialog_replace(DIALOG_076, 1, 6, 30, 200, "What are you staring at?\
I'm not stuck! I was\
just... admiring the\
view. Anyway, I found\
this ★ up here for you.\
I felt like I should\
do something in return\
for all the help you\
give us, Mario!")

smlua_text_utils_dialog_replace(DIALOG_077, 1, 3, 150, 200, "Some say that if you \
collect 120 power stars \
and pray to the Star\
Spirits from this spot by \
pressing [C]^, something \
good will happen.")

smlua_text_utils_dialog_replace(DIALOG_078, 1, 4, 30, 200, "★★★★★★★★★★★★★\
 Super Mario Star Road \
       by Skelux\
★★★★★★★★★★★★★\
Special thanks to:\
Frauber - Bug fixing and\
tools used.\
VL-Tone - Tools used.\
Yoshielectron - Helpful\
documents.\
Toxic - Play testing and\
various feedback.\
CPUhacka101 - Various\
feedback.\
SubDrag - Tools used.\
\
Thanks to the creators \
of most original MIDI \
files, and the \
original SM64 crew.\
Thanks to people who \
have supported\
Star Road and motivated\
me to keep working.\
★★★★★★★★★★★★★\
      Thanks for \
       playing!\
★★★★★★★★★★★★★")

smlua_text_utils_dialog_replace(DIALOG_079, 1, 4, 30, 200, "Owwwuu! Let me go!\
Uukee-kee! I was only\
teasing! Can't you take\
a joke?\
I'll tell you what, let's\
trade. If you let me go,\
I'll give you something\
really good.\
So, how about it?\
\
//Free him/ Hold on")

smlua_text_utils_dialog_replace(DIALOG_080, 1, 1, 30, 200, "Eeeh hee hee hee!")

smlua_text_utils_dialog_replace(DIALOG_081, 1, 4, 30, 200, "This is it, you have\
arrived at the Hidden\
Palace Finale, the\
final level! Even if\
you can not complete\
this challenge, you\
have done very well\
to make it this far.")

smlua_text_utils_dialog_replace(DIALOG_082, 1, 4, 30, 200, "I'm so glad to see you,\
Mario! Missing my\
jumping lessons really\
backfired... I came in\
here searching for a ★\
for you, and I couldn't\
reach the pipe to get\
back out!\
\
Anyway, you may as well\
take it now that you're\
here. Please give me\
a boost onto the pipe,\
too. Hehe.")

smlua_text_utils_dialog_replace(DIALOG_083, 1, 4, 30, 200, "Hi, Mario!\
When I heard that you\
collected enough power\
stars to fix the Star\
Road, I couldn't resist\
using it to see what\
this place was like!\
I love it, but\
it's a shame all those\
clouds are covering up\
the great view...\
\
By the way, I have a\
power star for you,\
Mario! ")

smlua_text_utils_dialog_replace(DIALOG_084, 1, 3, 30, 200, "Hey, put me down! \
I didn't say you could \
enter my house! How did \
you get in here, anyway? \
Look, just take this ★\
and don't come back.")

smlua_text_utils_dialog_replace(DIALOG_085, 1, 5, 30, 200, "You don't stand a ghost\
of a chance in this house.\
If you walk out of here,\
you deserve...\
...a Ghoul Medal...")

smlua_text_utils_dialog_replace(DIALOG_086, 1, 3, 30, 200, "Running around in circles\
makes some bad guys roll\
their eyes.")

smlua_text_utils_dialog_replace(DIALOG_087, 1, 4, 30, 200, "Santa Claus isn't the only\
one who can go down a\
chimney! Come on in!\
/--Cabin Proprietor")

smlua_text_utils_dialog_replace(DIALOG_088, 1, 5, 30, 200, "Does that rock look a\
little suspicious to\
you? Oh, it doesn't?\
Well, try standing on\
top of it and jumping\
anyway. Maybe you will\
find a hidden 1-up block!")

smlua_text_utils_dialog_replace(DIALOG_089, 1, 5, 95, 200, "Both ways fraught with\
danger! Watch your feet!\
Those who can't do the\
Long Jump, tsk, tsk. Make\
your way to the right.\
Right: Work Elevator\
/// Cloudy Maze\
Left: Black Hole\
///Underground Lake\
\
Red Circle: Elevator 2\
//// Underground Lake\
Arrow: You are here")

smlua_text_utils_dialog_replace(DIALOG_090, 1, 6, 30, 200, "Bwa ha ha ha!\
You've stepped right into\
my trap, just as I knew\
you would! I warn you,\
『Friend,』 watch your\
step!")

smlua_text_utils_dialog_replace(DIALOG_091, 2, 2, 30, 200, "Danger!\
Strong Gusts!\
But the wind makes a\
comfy ride.")

smlua_text_utils_dialog_replace(DIALOG_092, 1, 5, 30, 200, "Still trying to stop me,\
Mario? Even if you do\
manage to get past my\
delicious Blueberry Bully, \
you will never defeat me!\
Bwa ha ha!")

smlua_text_utils_dialog_replace(DIALOG_093, 1, 5, 30, 200, "I warned you, Mario.\
This mysterious world\
has given me so much\
power, you can even\
see my skin glowing\
with pure energy!\
I will flick you aside, \
and then the Mushroom\
Kingdom will be mine\
to rule! Bwa ha ha!")

smlua_text_utils_dialog_replace(DIALOG_094, 1, 4, 30, 200, "Get a good run up the\
slope! Do you remember\
the Long Jump? Run, press\
[Z], then jump!")

smlua_text_utils_dialog_replace(DIALOG_095, 1, 4, 30, 200, "To read a sign, stand in\
front of it and press [B],\
like you did just now.\
\
When you want to talk to\
a Koopa Troopa or other\
animal, stand right in\
front of it.\
Please recover the Stars\
that were stolen by\
Bowser in this course.")

smlua_text_utils_dialog_replace(DIALOG_096, 1, 4, 30, 200, "The path is narrow here.\
Easy does it! No one is\
allowed on top of the\
mountain!\
And if you know what's\
good for you, you won't\
wake anyone who's\
sleeping!\
Move slowly,\
tread lightly.")

smlua_text_utils_dialog_replace(DIALOG_097, 1, 3, 30, 200, "Hi Mario! How's my\
painting? Careful not\
to scratch it!")

smlua_text_utils_dialog_replace(DIALOG_098, 1, 2, 95, 200, "Come on in here...\
...heh, heh, heh...")

smlua_text_utils_dialog_replace(DIALOG_099, 1, 5, 95, 200, "Eh he he...\
You're mine, now, hee hee!\
I'll pass right through\
this wall. Can you do\
that? Heh, heh, heh!")

smlua_text_utils_dialog_replace(DIALOG_100, 1, 3, 95, 200, "Ukkiki...Wakkiki...kee kee!\
Ha! I snagged it!\
It's mine! Heeheeheeee!")

smlua_text_utils_dialog_replace(DIALOG_101, 1, 3, 95, 200, "Ackk! Let...go...\
You're...choking...me...\
Cough...I've been framed!\
This Cap? Oh, all right,\
take it. It's a cool Cap,\
but I'll give it back.\
I think it looks better on\
me than it does on you,\
though! Eeeee! Kee keee!")

smlua_text_utils_dialog_replace(DIALOG_102, 1, 5, 30, 200, "Pssst! The Boos are super\
shy. If you look them\
in the eyes, they fade\
away, but if you turn\
your back, they reappear.\
It's no use trying to hit\
them when they're fading\
away. Instead, sneak up\
behind them and punch.")

smlua_text_utils_dialog_replace(DIALOG_103, 1, 4, 95, 200, "Upon four towers\
one must alight...\
Then at the peak\
shall shine the light...")

smlua_text_utils_dialog_replace(DIALOG_104, 1, 5, 30, 200, "You did it, Mario! \
You've saved the \
Mushroom Kingdom from \
Bowser's terrors! We all \
have very much to \
thank you for once again, \
Mario. Keep searching for \
the rest of the power \
stars. The more we have, \
the more of Bowser's \
remaining troops we\
can banish from the\
kingdom.")

smlua_text_utils_dialog_replace(DIALOG_105, 1, 3, 95, 200, "Ready for blastoff! Go\
hop in the cannon when\
you are ready.")

smlua_text_utils_dialog_replace(DIALOG_106, 1, 2, 95, 200, "Ready for blastoff! Go\
hop in the cannon when\
you are ready.")

smlua_text_utils_dialog_replace(DIALOG_107, 1, 3, 95, 200, "...follow...the light...")

smlua_text_utils_dialog_replace(DIALOG_108, 1, 2, 95, 200, "Boooooo-m! Here comes\
the master of mischief,\
the tower of terror,\
the Big Boo!\
Ka ha ha ha...")

smlua_text_utils_dialog_replace(DIALOG_109, 1, 2, 95, 200, "You found the secret\
entrance to the lookout!")

smlua_text_utils_dialog_replace(DIALOG_110, 1, 5, 95, 200, "I need a good head on my\
shoulders. Do you know of\
anybody in need of a good\
body? Please! I'll follow\
you if you do!")

smlua_text_utils_dialog_replace(DIALOG_111, 1, 4, 95, 200, "Perfect! What a great\
new body! Here--this is a\
present for you. It's sure\
to warm you up.")

smlua_text_utils_dialog_replace(DIALOG_112, 1, 4, 30, 200, "Collect as many coins as\
possible! They'll refill\
your Power Meter.\
\
You can check to see how\
many coins you've\
collected in each of the\
15 enemy worlds.\
You can also recover\
power by touching the\
Spinning Heart.\
\
The faster you run\
through the heart, the\
more power you'll recover.")

smlua_text_utils_dialog_replace(DIALOG_113, 1, 4, 30, 200, "This window looks\
fairly damaged. A solid\
kick might be enough to\
finish the job...")

smlua_text_utils_dialog_replace(DIALOG_114, 1, 4, 95, 200, "Hey, you're the plumber\
who defeated the old\
Whomp King! Grr, but\
he was not even fit for\
king. Just a pathetic\
stepping stone. \
Well, don't think\
I'm going to be\
anything like that\
stack of cobble, I'm \
a whole new slab!")

smlua_text_utils_dialog_replace(DIALOG_115, 1, 3, 95, 200, "Why do you step on us\
like we are nothing?\
Maybe you will finally\
learn a thing or two\
when the rest of us\
arrive. Wahaha!")

smlua_text_utils_dialog_replace(DIALOG_116, 1, 5, 95, 200, "Ack!!! Defeated again!\
Next time it will be\
ME walking away with\
YOUR power stars, though.")

smlua_text_utils_dialog_replace(DIALOG_117, 1, 3, 95, 200, "BZZZT! INTRUDER!\
YOU MUST LEAVE OR\
BE DESTROYED!")

smlua_text_utils_dialog_replace(DIALOG_118, 1, 3, 95, 200, "BZZZT! CLUNK!\
EMERGENCY! ALL SYSTEMS\
FAILING!")

smlua_text_utils_dialog_replace(DIALOG_119, 1, 6, 30, 200, "Grrr! I was a bit\
careless. This is not as I\
had planned...but I still\
hold the power of the\
Stars, and I still have\
Peach.\
Bwa ha ha! You'll get no\
more Stars from me! I'm\
not finished with you yet,\
but I'll let you go for\
now. You'll pay for this...\
later!")

smlua_text_utils_dialog_replace(DIALOG_120, 1, 4, 30, 200, "Ooowaah! Can it be that\
I've lost??? The power of\
the Stars has failed me...\
this time.\
Consider this a draw.\
Next time, I'll be in\
perfect condition.\
\
Now, if you want to see\
your precious Princess,\
come to the top of the\
tower.\
I'll be waiting!\
Gwa ha ha ha!")

smlua_text_utils_dialog_replace(DIALOG_121, 1, 4, 30, 200, "Rarrgh! I can't believe\
you beat me, even with\
all this extra power... \
I should have\
been able to squash\
you like a bug!\
\
\
Don't think you've won\
though, Mario. As long \
as my troops still have\
any of the 120 power\
stars I gave them,\
they will have the\
strength to continue\
causing chaos everywhere,\
demonstrating the power\
of the Mushroom\
Kingdom's true ruler!\
Bwa ha ha!")

smlua_text_utils_dialog_replace(DIALOG_122, 1, 4, 30, 200, "--WARNING--\
PIPE NOT CURRENTLY \
SAFE TO ENTER.")

smlua_text_utils_dialog_replace(DIALOG_123, 1, 4, 30, 200, "You are about to enter\
Bowser's Slippery Swamp,\
home of the monster\
which Bowser gave the\
key to Star Leap Tower.")

smlua_text_utils_dialog_replace(DIALOG_124, 1, 4, 30, 200, "Work Elevator\
Danger!!\
Read instructions\
thoroughly!\
Elevator continues in the\
direction of the arrow\
activated.")

smlua_text_utils_dialog_replace(DIALOG_125, 1, 4, 30, 200, "Oh, the horror! On my\
way home from the shops\
yesterday, I was ambushed\
by a group of koopas who\
stole all my canned\
spaghetti! I tried again\
today, but the koopas\
stole it again! Please\
stop Bowser, Mario... \
You're a pasta-lover, \
I'm sure you know \
how I feel.")

smlua_text_utils_dialog_replace(DIALOG_126, 2, 3, 30, 200, "Up: Black Hole\
Right: Work Elevator\
/// Hazy Maze")

smlua_text_utils_dialog_replace(DIALOG_127, 3, 4, 30, 200, "Underground Lake\
Right: Metal Cave\
Left: Abandoned Mine\
///(Closed)\
A gentle sea dragon lives\
here. Pound on his back to\
make him lower his head.\
Don't become his lunch.")

smlua_text_utils_dialog_replace(DIALOG_128, 1, 4, 95, 200, "You must fight with\
honor! It is against the\
royal rules to throw the\
king out of the ring!")

smlua_text_utils_dialog_replace(DIALOG_129, 1, 5, 30, 200, "Welcome to the Vanish\
Cap Switch Course! All of\
the blue blocks you find\
will become solid once you\
step on the Cap Switch.\
You'll disappear when you\
put on the Vanish Cap, so\
you'll be able to elude\
enemies and walk through\
many things. Try it out!")

smlua_text_utils_dialog_replace(DIALOG_130, 1, 5, 30, 200, "Welcome to the Metal Cap\
Switch Course! Once you\
step on the Cap Switch,\
the green blocks will\
become solid.\
When you turn your body\
into metal with the Metal\
Cap, you can walk\
underwater! Try it!")

smlua_text_utils_dialog_replace(DIALOG_131, 1, 5, 30, 200, "Welcome to the Wing Cap\
Course! Step on the red\
switch at the top of the\
tower, in the center of\
the rainbow ring.\
When you trigger the\
switch, all of the red\
blocks you find will\
become solid.\
\
Try out the Wing Cap! Do\
the Triple Jump to take\
off and press [Z] to land.\
\
\
Pull back on the Control\
Stick to go up and push\
forward to nose down,\
just as you would when\
flying an airplane.")

smlua_text_utils_dialog_replace(DIALOG_132, 1, 4, 30, 200, "Woah, don't try to\
cheat! You're\
disqualified! Next time,\
play fair!")

smlua_text_utils_dialog_replace(DIALOG_133, 1, 6, 30, 200, "Am I glad to see you! The\
Princess...and I...and,\
well, everybody...we're all\
trapped inside the castle\
walls.\
\
Bowser has stolen the\
castle's Stars, and he's\
using their power to\
create his own world in\
the paintings and walls.\
\
Please recover the Power\
Stars! As you find them,\
you can use their power\
to open the doors that\
Bowser has sealed.\
\
There are four rooms on\
the first floor. Start in\
the one with the painting\
of Bob-omb inside. It's\
the only room that Bowser\
hasn't sealed.\
When you collect eight\
Power Stars, you'll be\
able to open the door\
with the big star. The\
Princess must be inside!")

smlua_text_utils_dialog_replace(DIALOG_134, 1, 5, 30, 200, "The names of the Stars\
are also hints for\
finding them. They are\
displayed at the beginning\
of each course.\
You can collect the Stars\
in any order. You won't\
find some Stars, enemies\
or items unless you select\
a specific Star.\
After you collect some\
Stars, you can try\
another course.\
We're all waiting for\
your help!")

smlua_text_utils_dialog_replace(DIALOG_135, 1, 5, 30, 200, "It was Bowser who stole\
the Stars. I saw him with\
my own eyes!\
\
\
He's hidden six Stars in\
each course, but you\
won't find all of them in\
some courses until you\
press the Cap Switches.\
The Stars you've found\
will show on each course's\
starting screen.\
\
\
If you want to see some\
of the enemies you've\
already defeated, select\
the Stars you recovered\
from them.")

smlua_text_utils_dialog_replace(DIALOG_136, 1, 6, 30, 200, "Wow! You've already\
recovered that many\
Stars? Way to go, Mario!\
I'll bet you'll have us out\
of here in no time!\
\
Be careful, though.\
Bowser and his band\
wrote the book on 『bad.』\
Take my advice: When you\
need to recover from\
injuries, collect coins.\
Yellow Coins refill one\
piece of the Power Meter,\
Red Coins refill two\
pieces, and Blue Coins\
refill five.\
\
To make Blue Coins\
appear, pound on Blue\
Coin Blocks.\
\
\
\
Also, if you fall from\
high places, you'll\
minimize damage if you\
Pound the Ground as you\
land.")

smlua_text_utils_dialog_replace(DIALOG_137, 1, 6, 30, 200, "Thanks, Mario! The castle\
is recovering its energy\
as you retrieve Power\
Stars, and you've chased\
Bowser right out of here,\
on to some area ahead.\
Oh, by the by, are you\
collecting coins? Special\
Stars appear when you\
collect 100 coins in each\
of the 15 courses!")

smlua_text_utils_dialog_replace(DIALOG_138, 1, 3, 30, 200, "Gee, that ★ must\
be pretty powerful to\
have done that to an\
ordinary wiggler...")

smlua_text_utils_dialog_replace(DIALOG_139, 1, 6, 30, 200, "Thanks for dealing with\
that huge brute! It looks\
like some of the trees\
have even started\
growing back!")

smlua_text_utils_dialog_replace(DIALOG_140, 1, 6, 30, 200, "So you're looking for\
power stars again, Mario?\
Well, I know about one\
that used to be at the\
bottom of the lake, but \
It's been so long that \
the giant tree seems to \
have absorbed it! Who \
knows if anyone will \
ever see it again...")

smlua_text_utils_dialog_replace(DIALOG_141, 1, 5, 150, 200, "You've recovered one of\
the Power Stars! Keep\
searching, you need\
7 more before you can\
open any sealed doors.")

smlua_text_utils_dialog_replace(DIALOG_142, 1, 4, 150, 200, "You should take a\
break occasionally,\
otherwise the game\
will be over before\
you know it!")

smlua_text_utils_dialog_replace(DIALOG_143, 1, 6, 150, 200, "Hurry! Bowser Is causing\
more chaos every minute!\
You have enough power\
stars to break the seals\
on the doors to Chuckya\
Harbor and Gloomy\
Garden, so get in there\
and hunt down some more\
power stars!")

smlua_text_utils_dialog_replace(DIALOG_144, 1, 6, 150, 200, "If you are having \
trouble finding a power\
star, remember to select \
the right ★ in the \
course menu.")

smlua_text_utils_dialog_replace(DIALOG_145, 1, 6, 150, 200, "Keep going! Once you've\
collected 65 of the\
power stars, you will \
have enough power to\
activate the Star Road!")

smlua_text_utils_dialog_replace(DIALOG_146, 1, 6, 150, 200, "Bowser must be shivering\
in his shell, you are\
very close to finding\
him now!")

smlua_text_utils_dialog_replace(DIALOG_147, 1, 5, 30, 200, "Are you using the Cap\
Blocks? You really should,\
you know.\
\
\
To make them solid so you\
can break them, you have\
to press the colored Cap\
Switches in the castle's\
hidden courses.\
You'll find the hidden\
courses only after\
regaining some of the\
Power Stars.\
\
The Cap Blocks are a big\
help! Red for the Wing\
Cap, green for the Metal\
Cap, blue for the Vanish\
Cap.")

smlua_text_utils_dialog_replace(DIALOG_148, 1, 6, 30, 200, "NOTICE:\
The annual 'Chucking the \
Furthest a Chuckya can \
Chuck' Competition will \
be postponed until next\
week, due to a lack of\
chuckable objects to \
chuck. \
\
Also, a note to\
participants, please \
remember that it is \
against the rules\
to distract another\
Chuckya by chuckling\
while he is chucking\
his chuckable object.")

smlua_text_utils_dialog_replace(DIALOG_149, 1, 3, 30, 200, "It's a disaster! Ever\
since the huge wiggler\
showed up, he's been\
raging around eating\
everything and now\
there's barely a tree\
left!\
\
Hey, if you have any\
experience tracking down\
giant tree-eating\
wigglers, your help sure\
would be appreciated!")

smlua_text_utils_dialog_replace(DIALOG_150, 1, 5, 30, 200, "Stomping sounds are\
travelling from far\
away bushes...")

smlua_text_utils_dialog_replace(DIALOG_151, 1, 4, 30, 200, "Hey, that hurt! I can \
eat as many trees as I \
like, there's nothing you \
can do about it!")

smlua_text_utils_dialog_replace(DIALOG_152, 1, 3, 30, 200, "Hey, knock it off! My\
head is really starting\
to hurt now!\
Fine, I'll stop eating\
so much on the condition\
you take this shiny\
thing from me. I've only\
ever had this huge\
appetite since I found\
it...")

smlua_text_utils_dialog_replace(DIALOG_153, 1, 4, 30, 200, "Hey! Who's there?\
What's climbing on me?\
Is it an ice ant?\
A snow flea?\
Whatever it is, it's\
bugging me! I think I'll\
blow it away!")

smlua_text_utils_dialog_replace(DIALOG_154, 1, 5, 30, 200, "So, are you going to\
get me out of here any\
time soon?")

smlua_text_utils_dialog_replace(DIALOG_155, 1, 6, 30, 200, "Really, I'm fine! I have\
this situation fully\
under control!")

smlua_text_utils_dialog_replace(DIALOG_156, 1, 4, 30, 200, "I guess you're\
wondering how to get\
off these boxes. Well,\
I've worked out two\
ways. You can use the\
cannon on the block\
behind me, or take a\
deep breath and dive\
through the clouds\
into the lake!")

smlua_text_utils_dialog_replace(DIALOG_157, 1, 5, 30, 200, "Brrrr! It's amazing \
you're not frozen to the \
spot in this kind of\
temperature! This is\
certainly not a place\
to be explored by an\
ordinary plumber.\
\
There are very dangerous\
drops in this place, not\
to mention the icy\
baddies, so you better\
watch your step!")

smlua_text_utils_dialog_replace(DIALOG_158, 1, 6, 30, 200, "Thanks for defeating\
Big Bob-omb Mario! With\
the strength of this\
recovered power star, we\
just might be able to\
knock out the enemy for\
good!")

smlua_text_utils_dialog_replace(DIALOG_159, 1, 6, 30, 200, "Ah, It's you again! I\
saw you defeat the Whomp\
King, and you have my\
genuine thanks for it.\
However, it looks like\
it was not enough to\
stop his dreadful plan.\
Some of his troops have\
arrived, but hopefully\
in time we will manage\
to drive them all out.")

smlua_text_utils_dialog_replace(DIALOG_160, 1, 4, 30, 200, "It's so peaceful to just\
sit down by the pond and \
watch the fish swim\
around...")

smlua_text_utils_dialog_replace(DIALOG_161, 1, 6, 30, 200, "Hi, Mario! It's great to\
see you again, but I have\
some bad news.\
Bowser learned the secret\
to reaching the world\
of the Star Spirits, and\
he's set up a base there.\
The big problem is that\
he now has access to\
a whole heap of\
Star Road portals which\
lead all over the\
Mushroom Kingdom!\
He's been using them to\
transport swarms of his\
troops, and they're\
causing chaos\
all over the place!\
Mario, if you are\
going to stop Bowser,\
you will need to use\
the Star Road at the\
top of Star-Leap Tower\
to find him. Bowser has \
sealed all the doors \
leading up the tower, but \
you should be able to\
break through if you can\
collect enough power\
stars to break the seals.\
Good luck!")

smlua_text_utils_dialog_replace(DIALOG_162, 1, 4, 30, 200, "Noooo! How could you\
have taken all 120\
power stars I gave\
to my troops!?\
It looks like you've\
really foiled my\
sneaky plan this time.\
Just remember, though,\
it doesn't mean you've\
seen the last of me!")

smlua_text_utils_dialog_replace(DIALOG_163, 1, 4, 30, 200, "Noooo! How could you\
have taken all 120\
power stars I gave\
to my troops!?\
It looks like you've\
really foiled my\
sneaky plan this time.\
Just remember, though,\
it doesn't mean you've\
seen the last of me!")

smlua_text_utils_dialog_replace(DIALOG_164, 1, 4, 30, 200, "Mario! What's up, pal?\
I haven't been on the\
slide lately, so I'm out\
of shape.\
Still, I'm always up for a\
good race.\
Whaddya say?\
Ready...set...\
\
//Go//// Don't Go")

smlua_text_utils_dialog_replace(DIALOG_165, 1, 5, 30, 200, "Wow, the lookout is\
finally safe to go on!\
It's about time too, I\
was missing these views.")

smlua_text_utils_dialog_replace(DIALOG_166, 1, 4, 30, 200, "I'm so glad that big\
brute is gone, I was\
biginning to think I'd\
never see the sunlight\
again!")

smlua_text_utils_dialog_replace(DIALOG_167, 1, 4, 30, 200, "Hello sir, welcome to\
the Sky Land Resort! I\
would like to be able to\
tell you this is a place\
to relax and enjoy the\
view, but unfortunatly\
we are having some\
trouble lately.\
One of Bowser's wacky\
troops calling himself\
the new Whomp King has\
just showed up, and\
he's threatening to\
take over this beautiful\
place! The residents are\
too scared to even leave\
their houses!")

smlua_text_utils_dialog_replace(DIALOG_168, 1, 5, 30, 200, "Ack! Stop it or I'll\
make you stop!")

smlua_text_utils_dialog_replace(DIALOG_169, 1, 6, 30, 200, "Psst! Looking for\
a challenge? Try pressing\
[R] after pausing the\
game, and select the\
'Super Mario Star Road'\
tab in the menu. For the\
SMSR veterans, try holding\
the L Button before you\
host a lobby with 'Super\
Mario Star Road' as the\
active romhack!")

function dialog_replace()
      if gGlobalSyncTable.hardMode then
            smlua_text_utils_dialog_replace(DIALOG_169, 1, 4, 30, 200, "Welcome to HARD MODE!\
This challenge mode is an\
OHKO, which means that\
everything-- and I mean\
EVERYTHING kills you in\
one hit! Do you have what\
it takes to complete this\
challenge?")
      else
            smlua_text_utils_dialog_replace(DIALOG_169, 1, 6, 30, 200, "Psst! Looking for\
a challenge? Try pressing\
[R] after pausing the\
game, and select the\
'Super Mario Star Road'\
tab in the menu. For the\
SMSR veterans, try holding\
the L Button before you\
host a lobby with 'Super\
Mario Star Road' as the\
active romhack!")
      end
end

hook_event(HOOK_ON_DIALOG, dialog_replace)